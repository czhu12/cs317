/*
 * eth_switch1.c
 * Author:
 */

#include <stdio.h>
#include <inttypes.h>

#include "eth_switch1.h"

/* Creates a new empty switch table (with no addresses associated to
 * any port).
 */
switch_table create_switch_table(void) {
  
  return NULL;
}

/* Handles an incoming Ethernet frame. This function is responsible
 * with updating the switch table with the data that can be deduced
 * from the frame, and returning a set of ports where the frame must
 * be forwarded to. The set of ports is represented by the port_set
 * type, and the function may return one of the following macros:
 *
 * - PORT_SET_NONE - Forward to no port at all (drop frame);
 * - PORT_SET_ALL - Forward to all ports;
 * - PORT_SET_ADD_PORT(s, p) - Forward to all ports in set s and to p (e.g., 
 *     PORT_SET_ADD_PORT(PORT_SET_NONE, 2) for port 2 only);
 * - PORT_SET_REMOVE_PORT(s, p) - Forward to all ports in set s but not to p (e.g., 
 *     PORT_SET_REMOVE_PORT(PORT_SET_ALL, 7) for all ports except 7);
 */
port_set forward_incoming_frame(switch_table *table, uint8_t port, uint16_t destination,
				uint16_t source, uint16_t frameid) {
  
  return PORT_SET_NONE;
}

/* Prints all the elements in the switch table in numerical order of
 * the MAC address. Elements are printed one per line, with each line
 * containing the MAC address (represented in hexadecimal with 4
 * characters) followed by a space and the port number (prefixed with
 * a P and with no leading zeros).
 */
void print_switch_table(switch_table table, FILE *output) {
  
  /* for each element in the switch table do:
     fprintf(output, "%04"PRIx16" P%"PRIu8"\n", mac_address, port);
   */
}

/* Frees any dynamically allocated space used by the switch table.
 */
void destroy_switch_table(switch_table table) {
  
}

